<?php

session_start();
header('Content-Type: application/json');

require_once("../class/hospitals.class.php");

if (!isset($_SESSION['logged_in'])) {
    echo json_encode([
        'status' => 'error',
        'message' => 'Unauthorized'
    ]);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] != 'POST') {
    echo json_encode([
        'status' => 'error',
        'message' => 'Invalid request'
    ]);
    exit;
}

$hospital = new hospital();

$id = $hospital->clean($_POST['id'] ?? '');

if (empty($id)) {
    echo json_encode([
        'status' => 'error',
        'message' => 'Hospital ID required'
    ]);
    exit;
}

$result = $hospital->deleteHospital($id);

if ($result) {
    echo json_encode([
        'status' => 'success',
        'message' => 'Hospital deleted successfully'
    ]);
} else {
    echo json_encode([
        'status' => 'error',
        'message' => 'Failed to delete hospital'
    ]);
}